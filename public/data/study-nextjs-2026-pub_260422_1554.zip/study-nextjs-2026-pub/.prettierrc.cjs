module.exports = {
  semi: true,
  singleQuote: true,
  tabWidth: 2,
  trailingComma: 'es5',
  printWidth: 120,
  arrowParens: 'always',
  endOfLine: 'auto'
}
